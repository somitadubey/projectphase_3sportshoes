package com.omkar.controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectPhase3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
