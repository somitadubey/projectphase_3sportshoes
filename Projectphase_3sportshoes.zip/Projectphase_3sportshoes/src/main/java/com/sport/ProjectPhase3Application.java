package com.sport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectPhase3Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjectPhase3Application.class, args);
	}

}
